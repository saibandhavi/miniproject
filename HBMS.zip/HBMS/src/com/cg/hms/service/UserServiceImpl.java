package com.cg.hms.service;

import com.cg.hms.beans.Hotel;
import com.cg.hms.beans.User;
import com.cg.hms.dao.IUserDao;
import com.cg.hms.exceptions.HMSException;



public class UserServiceImpl implements IUserService{

	IUserDao dao;
	@Override
	public String getRole(String username, String password) throws HMSException {
		return dao.getRole(username, password);
	}
	@Override
	public String getRegistered(User user) {
		return dao.getRegistered(user);
	}
	@Override
	public String getUserId(String username, String password) throws HMSException {
		return dao.getUserId(username,password);
	}
	@Override
	public Hotel getHotelDetails(String hotelId) throws HMSException {
		return dao.getHotelDetails(hotelId);
	}
	}
	
	



package com.cg.hms.service;

import com.cg.hms.beans.Hotel;
import com.cg.hms.beans.User;
import com.cg.hms.exceptions.HMSException;

public interface IUserService {

	String getRole(String username,String password) throws HMSException;

	String getRegistered(User user);

	String getUserId(String username, String password) throws HMSException;

	Hotel getHotelDetails(String hotelId) throws HMSException;
}

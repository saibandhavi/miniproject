package com.cg.hms.exceptions;

public class HMSException extends Exception{
	String message;

	public HMSException(String message) {
		super();
		this.message = message;
	}

	public HMSException() {
	}
}

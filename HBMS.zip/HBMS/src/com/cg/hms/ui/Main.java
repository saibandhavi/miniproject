package com.cg.hms.ui;

import java.util.Scanner;

import com.cg.hms.beans.Hotel;
import com.cg.hms.beans.User;
import com.cg.hms.exceptions.HMSException;
import com.cg.hms.service.IUserService;
import com.cg.hms.service.UserServiceImpl;

public class Main {

	public static void main(String[] args) throws HMSException {
		int choice = 0;
		IUserService service=new UserServiceImpl();
		Scanner sc = new Scanner(System.in);
		System.out.println("1.Register\n2.Login");
	
		choice = sc.nextInt();
		switch (choice) {
		case 1:
			int option = sc.nextInt();
			
			if (option == 1) {
				UserReg reg = new UserReg();
				User user=reg.register();
				String userId=service.getRegistered(user);
				System.out.println("Sucessfully registered with userId"+userId);
			} else if (option == 2) {
				System.out.println("Enter ID of the employee hotel");
				String hotelId=sc.nextLine();
				
				Hotel hotel=service.getHotelDetails(hotelId);
				
			}

			break;

		case 2:
			
			
			
			System.out.println("Enter username:");
			String username=sc.nextLine();
			System.out.println("Enter password:");
			String password=sc.nextLine();
			
			
			try {
				String	role = service.getRole(username, password);
				String userId=service.getUserId(username,password);
				System.out.println(role);
				if(role.equalsIgnoreCase("Employee")){
					EmployeeConsole empConsole=new EmployeeConsole();
					empConsole.home();
					}
				else if(role.equalsIgnoreCase("User")){
					UserReg userConsole=new UserReg();
					userConsole.home(username, userId);
					}
			} catch (HMSException e) {
				System.out.println(e.getMessage());
			}
			
			

			break;

		case 3:
			System.exit(0);
		}

	}

}

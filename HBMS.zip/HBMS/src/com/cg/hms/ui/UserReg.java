package com.cg.hms.ui;

import java.util.Scanner;

import com.cg.hms.beans.User;

public class UserReg {
	User user = new User();
	Scanner sc = new Scanner(System.in);

	public User register() {
		System.out.println("Enter username:");
		String username = sc.nextLine();
		System.out.println("Enter password:");
		String password = sc.nextLine();
		System.out.println("Enter address");
		String address = sc.nextLine();
		System.out.println("Enter mobile no");
		String mobileNo = sc.nextLine();
		System.out.println("Enter email:");
		String email = sc.nextLine();
		System.out.println("Enter phone:");
		String phoneNo = sc.nextLine();
		System.out.println("Enter role:");
		String role = "Customer";
		User user = new User(password, role, username, mobileNo, phoneNo,
				address, email);
		return user;
	}

	public void home(String username, String userId) {
		int choice = 0;
		choice = sc.nextInt();
		System.out.println("Welcome " + username);
		System.out.println("Hotel Booking");
		System.out.println("Choose the following" + "1.Search for hotel"
				+ "2.Booking hotel" + "3.Booking status" + "4.Exit");

	}
}

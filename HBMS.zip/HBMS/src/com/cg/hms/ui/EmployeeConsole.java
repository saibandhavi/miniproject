package com.cg.hms.ui;

public class EmployeeConsole {

	public void home() {
		
	}

}

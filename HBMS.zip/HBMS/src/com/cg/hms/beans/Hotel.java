package com.cg.hms.beans;

public class Hotel {

	private String hotelName;
	private String hotelId;
	private String city;
	private String address;
	private String description;
	private String rating;
	private String phone1;
	private String phone2;
	private double rate;
	private String email;
	private String fax;
	public Hotel() {
		super();
	}
	public Hotel(String hotelName, String hotelId, String city, String address,
			String description, String rating, String phone1, String phone2,
			double rate, String email, String fax) {
		super();
		this.hotelName = hotelName;
		this.hotelId = hotelId;
		this.city = city;
		this.address = address;
		this.description = description;
		this.rating = rating;
		this.phone1 = phone1;
		this.phone2 = phone2;
		this.rate = rate;
		this.email = email;
		this.fax = fax;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getHotelId() {
		return hotelId;
	}
	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getPhone1() {
		return phone1;
	}
	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}
	public String getPhone2() {
		return phone2;
	}
	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	@Override
	public String toString() {
		return "Hotel [hotelName=" + hotelName + ", hotelId=" + hotelId
				+ ", city=" + city + ", address=" + address + ", description="
				+ description + ", rating=" + rating + ", phone1=" + phone1
				+ ", phone2=" + phone2 + ", rate=" + rate + ", email=" + email
				+ ", fax=" + fax + "]";
	}
	
	
}

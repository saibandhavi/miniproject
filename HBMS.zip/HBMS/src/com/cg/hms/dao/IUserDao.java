package com.cg.hms.dao;

import com.cg.hms.beans.Hotel;
import com.cg.hms.beans.User;
import com.cg.hms.exceptions.HMSException;

public interface IUserDao {

	String getRole(String username,String password) throws HMSException;

	String getRegistered(User user);

	String getUserId(String username, String password) throws HMSException;

	Hotel getHotelDetails(String hotelId) throws HMSException;

}

package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.hms.beans.Hotel;
import com.cg.hms.beans.User;
import com.cg.hms.exceptions.HMSException;
import com.cg.hms.utility.JdbcUtility;

public class UserDaoImpl implements IUserDao{

	Connection connection=null;
	PreparedStatement preparedStatement=null;
	@Override
	public String getRole(String username,String password) throws HMSException {
		String role = null;
		connection = JdbcUtility.getConnection();
		try {
			preparedStatement = connection
					.prepareStatement(QueryConstants.Query1);
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, password);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				role = resultSet.getString(1);
			} else {
				role = "Invalid Credentials or Username Does not exists";
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return role;
	}
	@Override
	public String getRegistered(User user) {
		return null;
	}
	@Override
	public String getUserId(String username, String password) throws HMSException {
		
		String getUserId=null;
		connection = JdbcUtility.getConnection();
		
		try {
			preparedStatement=connection.prepareStatement(QueryConstants.Query2);
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, password);
			ResultSet resultSet=preparedStatement.executeQuery();
			if (resultSet.next()) {
				getUserId=resultSet.toString();
			}
			else
			{
				getUserId="Invalid credentials or username does not exist";
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return getUserId;
	}
	@Override
	public Hotel getHotelDetails(String hotelId) throws HMSException {
		
		
		connection = JdbcUtility.getConnection();
		
		try {
			preparedStatement=connection.prepareStatement(QueryConstants.Query3);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

}

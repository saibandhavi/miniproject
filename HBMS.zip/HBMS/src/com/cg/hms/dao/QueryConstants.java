package com.cg.hms.dao;

public interface QueryConstants {
	String Query1="";
	String Query2 = "";
	String Query3 = null;
}
